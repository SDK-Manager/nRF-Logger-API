The jar files were created before the project was submitted on Maven Central repository.

Please, use Maven Central to obtain the newer versions.